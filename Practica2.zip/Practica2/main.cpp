#include <iostream>
#include <stdlib.h>
#include <time.h>

using namespace std;

//PRACTICA #2 JULIAN PEREZ LOPEZ-1000566319
//===============================

//===========EN QT=============

//      PROBLEMA 1
/*int main()
{
    int din,b50=0,b20=0,b10=0,b5=0,b2=0,b1=0,m5=0,m2=0,m1=0,m50=0;
    cout<<"Ingrese el dinero";
    cin>>din;
    if (din/50000>=1){
        b50=din/50000;
        din=din%50000;
    }
    if (din/20000>=1){
        b20=din/20000;
        din=din%20000;
    }
    if (din/10000>=1){
        b10=din/10000;
        din=din%10000;
    }
    if (din/5000>=1){
        b5=din/5000;
        din=din%5000;
    }
    if (din/2000>=1){
        b2=din/2000;
        din=din%2000;
    }
    if (din/1000>=1){
        b1=din/1000;
        din=din%1000;
    }
    if (din/500>=1){
        m5=din/500;
        din=din%500;
    }
    if (din/200>=1){
        m2=din/200;
        din=din%200;
    }
    if (din/100>=1){
        m1=din/100;
        din=din%100;
    }
    if (din/50>=1){
        m50=din/50;
        din=din%50;
    }
    cout<<"50000:"<<b50<<endl;
    cout<<"20000:"<<b20<<endl;
    cout<<"10000:"<<b10<<endl;
    cout<<"5000:"<<b5<<endl;
    cout<<"2000:"<<b2<<endl;
    cout<<"1000:"<<b1<<endl;
    cout<<"500:"<<m5<<endl;
    cout<<"200:"<<m2<<endl;
    cout<<"100:"<<m1<<endl;
    cout<<"50:"<<m50<<endl;
    cout<<"Restante:"<<din<<endl;
}*/

//==========EN ARDUINO===========

/*long int din[10]={50000,20000,10000,5000,2000,1000,500,200,100,50},cant[10]={},dine;
void setup()
{
  Serial.begin(9600);
  Serial.println("Ingrese la cantidad de dinero");
}

void loop()
{
  if (Serial.available()){
    dine=Serial.parseInt();
    for (int i=0;i<=9;i++){
        cant[i]=dine/din[i];
        dine=dine%din[i];
        Serial.print(din[i],DEC);
        Serial.print(": ");
        Serial.println(cant[i],DEC);
    }
    Serial.print("Faltante: ");
    Serial.println(dine,DEC);
  }
}*/

//      -------------PROBLEMA 2--------------
/*
int main(){
    char letras[26]={'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};
    int num;
    char arreglo[200]={};
    srand(time(NULL));
    for (int i=0;i<200;i++){
        num=rand()%26;
        //cout<<num<<" "<<letras[num]<<endl;
        arreglo[i]=letras[num];
        //cout<<arreglo[i];
    }
    for (int i=0;i<26;i++){
        int cont=0;
        for (int j=0;j<200;j++){
            if (letras[i]==arreglo[j]) cont++;
        }
        cout<<letras[i]<<": "<<cont<<endl;
    }
}*/

//------------------PROBLEMA 4--------------------
/*
int potencia(int);
void convaint(string,int *);
int main(){
    string a;
    int b;
    cout<<"Ingrese un numero"<<endl;cin>>a;
    convaint(a,&b);
    cout<<b<<endl;
}
int potencia(int a){
    int res;
    res=1;
    for (int i=1;i<=a;i++)
    {
        res=res*10;
    }
    //cout<<" "<<res<<endl;
    return res;
}
void convaint(string a,int *b){
    int res=0,cont=0,n;
    char num[]={'0','1','2','3','4','5','6','7','8','9'};
    for (int i=0;a[i]!='\0';i++) cont++;
    //cout<<"contador"<<cont<<endl;
    for (int i=0;cont>0;i++,cont--){
        int j=0;
        while(j<=9){
            if (a[i]==num[j]){
                n=j;
                j=10;
            }
            j++;
        }
        res=res+(n*potencia(cont-1));
    }
    *b=res;
}*/

//-------------PROBLEMA 5------------
/*
int convastr(int num,string *cad);
int potencia(int a);
int main(){
    int num;
    cout<<"Ingrese un numero"<<endl;cin>>num;
    string j={};
    convastr(num,&j);
    cout<<j;
}
int potencia(int a){
    int res;
    res=1;
    for (int i=1;i<=a;i++)
    {
        res=res*10;
    }
    //cout<<" "<<res<<endl;
    return res;
}
int convastr(int num,string *cad){
    int nnum=num,lon;
    char nums[]={'0','1','2','3','4','5','6','7','8','9'};
    string cade="";
    for (int i=1;nnum!=0;i++){
        nnum/=10;
        lon=i;
    }
    int div=potencia(lon-1);
    for (int i=0;div>=1;i++){
        cade=cade+nums[num/div];
        num=num%div;
        div=div/10;
    }
    *cad=cade;
}*/

//--------------PROBLEMA 7------------
/*
int main(){
    string a,nuevo="";
    cout<<"Ingrese una cadena de caracteres"<<endl;cin>>a;
     for (int i=0;a[i]!='\0';i++){
         for (int k=0;k<i;k++)nuevo=nuevo+a[k];
         nuevo=nuevo+a[i];
         for (int j=i;a[j]!='\0';j++){
             if (a[i]!=a[j])nuevo=nuevo+a[j];}
         a=nuevo;
         nuevo="";
         cout<<a<<endl;
     }
}*/

//--------------PROBLEMA 10------------

/*
int main(){
    char rom[]={'I','V','X','L','C','D','M'};
    int ent[]={1,5,10,50,100,500,1000},nant=8,num=0;
    string entra="";
    cout<<"Ingrese un numero romano, letras en mayusculas"<<endl;cin>>entra;
    cout<<"El numero ingresado fue: "<<entra<<endl;
    for (int i=0;entra[i]!='\0';i++){
        for (int j=0;j<7;j++){
            if (nant>=j){
                if (entra[i]==rom[j]){
                    num=num+ent[j];
                    nant=j;
                }
            }
            if (nant<j){
                if (entra[i]==rom[j]){
                    num=num+ent[j]-2*ent[nant];
                    nant=j;
                }
            }
        }
    }
    cout<<"Que corresponde a: "<<num<<endl;
}*/

//=============EN ARDUINO================

/*char rom[]={'I','V','X','L','C','D','M'};
int ent[]={1,5,10,50,100,500,1000},nant=8,num=0;
String entra="";
void setup()
{
  Serial.begin(9600);
  Serial.println("Ingrese un numero romano, letras en mayusculas");

}

void loop()
{
  if (Serial.available()){
    nant=8;
    num=0;
    entra="";
    entra=Serial.readStringUntil('\n');
    Serial.print("El numero ingresado fue: ");
    Serial.println(entra);
    for (int i=0;entra[i]!='\0';i++){
        for (int j=0;j<7;j++){
            if (nant>=j){
                if (entra[i]==rom[j]){
                    num=num+ent[j];
                    nant=j;
                }
            }
            if (nant<j){
                if (entra[i]==rom[j]){
                    num=num+ent[j]-2*ent[nant];
                    nant=j;
                }
            }
        }
    }
    Serial.print("Que corresponde a: ");
    Serial.println(num);
  }
}*/

//------------PROBLEMA 12----------------
/*
void generar(int** matriz,int filas,int columnas);
void imprimir(int** matriz,int filas,int columnas);
bool verif_col(int **matriz,int i,int filas,int res);
bool verif_fil(int **matriz,int i,int filas,int res);
bool verif_dia(int **matriz,int filas,int res);
int main(){
    int filas,colum,res=0;
    bool j=1;
    cout<<"Filas: "<<endl;cin>>filas;
    cout<<"Columnas; "<<endl;cin>>colum;
    int **matriz=new int*[filas];
    for (int i=0;i<filas;i++){
        matriz[i]=new int[colum];
    }
    generar(matriz,filas,colum);
    imprimir(matriz,filas,colum);
    for(int i=0;i<filas;i++)res=res+matriz[0][i];
    //filas
    int i=0;
    while(i<filas){
        j=verif_col(matriz,i,filas,res);
        j=verif_fil(matriz,i,filas,res);
        j=verif_dia(matriz,filas,res);
        i++;
    }
    if (j)cout<<"Es un cuadrado magico"<<endl;
    else cout<<"No es un cuadrado magico"<<endl;
}
void generar(int** matriz,int filas,int columnas){
    int valor;
    for (int i=0;i<filas;i++){
        for (int j=0;j<columnas;j++){
            cout<<"Ingrese el valor en la posicion :"<<"["<<i<<"]"<<"["<<j<<"]"<<endl;
            cin>>valor;
            matriz[i][j]=valor;
        }
    }
}
void imprimir(int** matriz,int filas,int columnas){
    for (int i=0;i<filas;i++){
        for (int j=0;j<columnas;j++)cout<<matriz[i][j]<<" ";
        cout<<endl;
    }

}
bool verif_fil(int **matriz,int i,int filas,int res){
    int suma=0;
    for (int j=0;j<filas;j++){
        suma=suma+matriz[i][j];
    }
    if (suma==res)return true;
    else return false;
}
bool verif_col(int **matriz,int i,int filas,int res){
    int suma=0;
    for (int j=0;j<filas;j++){
        suma=suma+matriz[j][i];
    }
    if (suma==res)return true;
    else return false;
}
bool verif_dia(int **matriz,int filas,int res){
    int suma=0;
    for (int j=0,i=0;j<filas;j++,i++){
        suma=suma+matriz[j][i];
    }
    if (suma==res)return true;
    else {
        //cout<<"No es un cuadrado magico"<<"caso4"<<endl;
        return false;
    }
}*/

//-------------PROBLEMA 13------------------
/*
void rellenar( int **matriz);
int nestrellas(int **matriz);
int main(){
    int **matriz=new int*[6];
    for(int i=0;i<6;i++){
        matriz[i]=new int[8];
    }
    rellenar(matriz);
    cout<<nestrellas(matriz)<<endl;
}
int nestrellas(int **matriz){
    int cont=0;
    for (int i=0;i<6;i++){
        for (int j=0;j<8;j++){
            if ((i-1)>0 and (i+1)<6 and (j-1)>0 and (j+1)<8){
                if (float((matriz[i][j]+matriz[i-1][j]+matriz[i+1][j]+matriz[i][j+1]+matriz[i][j-1])/5)>6)cont++;
            }
        }
    }
    return cont;
}
void rellenar( int **matriz){
    int cont=0;
    int llenador[48]={0,3,4,0,0,0,6,8,5,13,6,0,0,0,2,3,2,6,2,7,3,0,10,0,0,0,4,15,4,1,6,0,0,0,7,12,6,9,10,4,5,0,6,10,6,4,8,0};
    for (int i=0;i<6;i++){
        for (int j=0;j<8;j++){
            matriz[i][j]=llenador[cont];
            cont++;
        }
    }
}*/

//-----------------------PROBLEMA 15----------------------
/*
int intercepcion(int *rect1,int *rect2,int*rect3);
int main(){
    int x1,y1,a1,l1,x2,y2,a2,l2;
    cout<<"Ingrese la coordenada x del rectangulo "<<1<<endl;cin>>x1;
    cout<<"Ingrese la coordenada y del rectangulo "<<1<<endl;cin>>y1;
    cout<<"Ingrese el ancho del rectangulo "<<1<<endl;cin>>a1;
    cout<<"Ingrese el largo del rectangulo "<<1<<endl;cin>>l1;
    cout<<"Ingrese la coordenada x del rectangulo "<<2<<endl;cin>>x2;
    cout<<"Ingrese la coordenada y del rectangulo "<<2<<endl;cin>>y2;
    cout<<"Ingrese el ancho del rectangulo "<<2<<endl;cin>>a2;
    cout<<"Ingrese el largo del rectangulo "<<2<<endl;cin>>l2;
    int rect1[4]={x1,y1,a1,l1},rect2[4]={x2,y2,a2,l2},rect3[4]={0,0,0,0};
    intercepcion(rect1,rect2,rect3);
    cout<<rect3[0]<<" "<<rect3[1]<<" "<<rect3[2]<<" "<<rect3[3]<<endl;
}
int intercepcion(int *rect1,int *rect2,int*rect3){
    int x,y,a,l;
    if (rect1[0]<rect2[0] and rect2[0]<(rect1[0]+rect1[2])){
        x=rect2[0];
        if (((rect1[2]+rect1[0])-x)>rect2[2]){
            a=rect2[2];
        }
        else a=(rect1[2]+rect1[0])-x;
    }
    else {
        x=rect1[0];
        if (((rect2[2]+rect2[0])-x)>rect1[2]){
            a=rect1[2];
        }
        else a=(rect2[2]+rect2[0])-x;
    }
    if (rect1[1]<rect2[1] and rect2[1]<(rect1[1]+rect1[3])){
        y=rect2[1];
        if (((rect1[3]+rect1[1])-y)>rect2[3]){
            l=rect2[3];
        }
        else l=(rect1[3]+rect1[1])-y;
    }
    else {
        y=rect1[1];
        if (((rect2[3]+rect2[1])-y)>rect1[3]){
            l=rect1[3];
        }
        else l=(rect2[3]+rect2[1])-y;
    }
    rect3[0]=x;
    rect3[1]=y;
    rect3[2]=a;
    rect3[3]=l;
}*/

//-------------------PROBLEMA 18---------------
/*
int potencia(int a){
    int res;
    res=1;
    for (int i=1;i<=a;i++)
    {
        res=res*10;
    }
    //cout<<" "<<res<<endl;
    return res;
}
int convastr(int num,string *cad){
    int nnum=num,lon;
    char nums[]={'0','1','2','3','4','5','6','7','8','9'};
    string cade="";
    for (int i=1;nnum!=0;i++){
        nnum/=10;
        lon=i;
    }
    int div=potencia(lon-1);
    for (int i=0;div>=1;i++){
        cade=cade+nums[num/div];
        num=num%div;
        div=div/10;
    }
    *cad=cade;
}
int compa(string a,int lon){
    for (int i=0;i<lon;i++){
        if ((i+1)<9){
        for (int j=i+1;j<lon;j++){
            if (a[i]==a[j])return false;
        }}
    }
    return true;
}
int main(){
    int n,cont=1,lon;
    string a="";
    long long int permutacion=123456789;
    cout<<"ingrese un numero"<<endl;cin>>n;
    while (cont<n){
        lon=0;
        permutacion+=9;
        convastr(permutacion,&a);
        cout<<"PRUEBA"<<a<<endl;
        for (int i=0;a[i]!='\0';i++)lon++;
        if (lon<10)a='0'+a;
        if (compa(a,10))cont++;
    }
    cout<<a<<endl;
}
*/
